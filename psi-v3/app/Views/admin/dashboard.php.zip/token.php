<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin | Users</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url() ?>/plugins/fontawesome-free/css/all.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?= base_url() ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <link rel="icon" href="images/bg/favicon.ico" type="image/gif">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url() ?>/dist/dist/css/adminlte.min.css">
    <style>
    #loader-wrapper {
	display: flex;
	position: fixed;
	z-index: 1060;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	flex-direction: row;
	align-items: center;
	justify-content: center;
	padding: 0.625em;
	overflow-x: hidden;
	transition: background-color 0.1s;
	background-color: rgb(253 253 253 / 58%);
	-webkit-overflow-scrolling: touch;
}

.loader {
	border: 10px solid #f3f3f3;
	border-radius: 50%;
	border-top: 10px solid #3af3f5;
	border-bottom: 10px solid #3abcec;
	width: 50px;
	height: 50px;
	-webkit-animation: spin 2s linear infinite;
	animation: spin 2s linear infinite;
	margin: 1.75rem auto;
}

	

		@keyframes fadeIn {
		  0% {
		    opacity: 0;
		  }
		  100% {
		    opacity: 1;
		  }
		}

		@-moz-keyframes fadeIn {
		  0% {
		    opacity: 0;
		  }
		  100% {
		    opacity: 1;
		  }
		}

		@-webkit-keyframes fadeIn {
		  0% {
		    opacity: 0;
		  }
		  100% {
		    opacity: 1;
		  }
		}

		@-o-keyframes fadeIn {
		  0% {
		    opacity: 0;
		  }
		  100% {
		    opacity: 1;
		  }
		}

		@-ms-keyframes fadeIn {
		  0% {
		    opacity: 0;
		  }
		  100% {
		    opacity: 1;
		  }
		}

		@-webkit-keyframes spin {
		  0% {
		    -webkit-transform: rotate(0deg);
		  }
		  100% {
		    -webkit-transform: rotate(360deg);
		  }
		}

		@keyframes spin {
		  0% {
		    transform: rotate(0deg);
		  }
		  100% {
		    transform: rotate(360deg);
		  }
		}
  </style>
</head>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">
        <!-- Navbar -->


        <?= $this->include('admin/navbar') ?>
        <!-- /.navbar -->
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Data Token</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
                                <li class="breadcrumb-item active">Token</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="row col-md-12" style="align-items: center;">
                                        <div class="col-md-1">
                                            <label for="date">Tanggal :</label>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <input class="form-control" type="date" name="start_dttm"
                                                    id="start_dttm" value="<?= date("Y-m-d") ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-1 d-flex justify-content-center">
                                            <label>s/d</label>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <input class="form-control" type="date" name="end_dttm" id="end_dttm"
                                                    value="<?= date("Y-m-d") ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <button class="btn btn-primary" type="button"
                                                    onclick="tampilkantoken()">Tampilkan</button>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <button style="float: right;" class="btn btn-success" type="button"
                                                    onclick="tambahtoken()">Tambah</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table id="table_token" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th style="text-align:center;">No.</th>
                                                <th style="text-align:center;">Token</th>
                                                <th style="text-align:center;">Tanggal</th>
                                                <th style="text-align:center;">Status</th>
                                                <th style="text-align:center;">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $no = 1;
                                                foreach ($token as $key) {
                                            ?>
                                            <tr>
                                                <td class="text-center" width="30"><?= $no++; ?></td>
                                                <td class="text-center"> <?= $key->token ?> </td>
                                                <td class="text-center"> <?= $key->start_date ?> s/d
                                                    <?= $key->end_date ?> </td>
                                                <td class="text-center"> status </td>
                                                <td class="text-center">
                                                    <button
                                                        onclick="edit(this)"
                                                        value="<?= $key->token_id ?>|<?= $key->start_date ?>|<?= $key->end_date ?>|<?= $key->token ?>"
                                                        class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></button>
                                                        <button
                                                        onclick="hapus(<?= $key->token_id ?>)"
                                                        class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                                </td>
                                            </tr>
                                            <?php  } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
            <div class="modal fade" id="modal-tambah">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-blue">
                            <h4><label for="">Form Tambah Token</label></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div id="modal_body" class="modal-body">
                            <div class="row col-md-12">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="token">Token</label>
                                        <input class="form-control" type="text" name="token" id="token" maxlength="6" minlength="6">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="start_dttm">Tanggal Awal</label>
                                        <input class="form-control" type="date" name="start_dttm" id="start_dttm">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="end_dttm">Tanggal Akhir</label>
                                        <input class="form-control" type="date" name="end_dttm" id="end_dttm">
                                    </div>
                                </div>
                            </div>
                            <div>
                            <div class="col-md-12 d-flex justify-content-center">
                                    <div class="form-group">
                                        <button class="btn btn-primary" type="button" onclick="simpantoken()">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modal-edit">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-blue">
                            <h4><label for="">Form Tambah Token</label></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div id="modal_body" class="modal-body">
                            <input type="hidden" id="token_id_edit" name="token_id_edit">
                            <div class="row col-md-12">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="token">Token</label>
                                        <input class="form-control" type="text" name="token_edit" id="token_edit" maxlength="6" minlength="6">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="start_dttm">Tanggal Awal</label>
                                        <input class="form-control" type="date" name="start_dttm_edit" id="start_dttm_edit">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="end_dttm">Tanggal Akhir</label>
                                        <input class="form-control" type="date" name="end_dttm_edit" id="end_dttm_edit">
                                    </div>
                                </div>
                            </div>
                            <div>
                            <div class="col-md-12 d-flex justify-content-center">
                                    <div class="form-group">
                                        <button class="btn btn-primary" type="button" onclick="updatetoken()">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-none" id='loader-wrapper'>
                <div class="loader"></div>
            </div>
        </div>
    </div>


    <!-- jQuery -->
    <script src="<?= base_url() ?>/plugins/jquery/jquery.min.js"></script>
    <script src="<?= base_url() ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?= base_url() ?>/dist/dist/js/adminlte.min.js"></script>
    <!-- Page specific script -->
    <script>
      

    function tambahtoken() {
        $("#modal-tambah").modal("show");
    }

    function simpantoken() {
      var token = $("#token").val()
      var start_dttm = $("#start_dttm").val()
      var end_dttm = $("#end_dttm").val()
      $.ajax({
        url: "<?= base_url('admin/token/simpantoken') ?>",
        type: "post",
        dataType: "json",
        data: {
          "token": token,
          "start_date": start_dttm,
          "end_date": end_dttm
        },
        beforeSend: function() {
            $("#loader-wrapper").removeClass("d-none");
        },
        success: function(data) {
          if (data == "sukses") {
              alert("Token berhasil disimpan");
          } else {
              alert("Token gagal disimpan");
          }
          $("#loader-wrapper").addClass("d-none");
          $("#modal-tambah").modal("hide");
        },
        error: function() {
          alert("Error");
          $("#loader-wrapper").addClass("d-none");
        }
      });
    }

    function edit(edit) {
        const [token_id, start_date, end_date, token] = $(
                    edit).attr("value")
                .split("|")
        $("#modal-edit").modal("show");
        $("#token_id_edit").val(token_id);
        $("#start_dttm_edit").val(start_date);
        $("#end_dttm_edit").val(end_date);
        $("#token_edit").val(token);
    }

    function updatetoken() {
        let token_id = $("#token_id_edit").val();
        let start_date = $("#start_dttm_edit").val();
        let end_date = $("#end_dttm_edit").val();
        let token = $("#token_edit").val();
        $.ajax({
            url: "<?= base_url('admin/token/updatetoken') ?>",
            type: "post",
            dataType: "json",
            data: {
                "token": token,
                "start_date": start_date,
                "end_date": end_date,
                "token_id": token_id
            },
            beforeSend: function() {
                $("#loader-wrapper").removeClass("d-none");
            },
            success: function(data) {
                if (data == "sukses") {
                    alert("Token berhasil disimpan");
                } else {
                    alert("Token gagal disimpan");
                }
                $("#loader-wrapper").addClass("d-none");
                $("#modal-tambah").modal("hide");
            },
            error: function() {
                alert("Error");
                $("#loader-wrapper").addClass("d-none");
            }
        });
    }

    function hapus(token_id) {
        let text = "Apakah anda yakin menghapus data ini ?";
        if (confirm(text) == true) {
            $.ajax({
                url: "<?= base_url('admin/tokeb/hapustoken') ?>",
                type: "post",
                dataType: "json",
                data: {
                    "token_id": token_id
                },
                beforeSend: function() {
                    $("#loader-wrapper").removeClass("d-none")
                },
                success: function(data) {
                    if (data == true) {
                        alert("hapus token berhasil");
                    } else {
                        alert("hapus token gagal");
                    }
                    $("#loader-wrapper").addClass("d-none");
                },
                error: function() {
                    alert("error");
                    $("#loader-wrapper").addClass("d-none");
                }
            });
        }
    }

    loadDataToken = () => {
        var start_date = $("#start_date").val();
        var end_date = $("#end_date").val();
            $("#table_token").DataTable({
                ajax: {
                    url: "/admin/token/loadDataToken",
                    type: "GET",
                    data: function(d) {
                        d.start_date = start_date,
                        d.end_date = end_date
                    },
                    dataSrc: function(json) {
                        let nomor = 1
                        json.forEach((row, idx) => {
                            if (idx > 0) {
                                nomor++
                            }
                            row.nomor = nomor
                        });

                        return json
                    }
                },
                bDestroy: true,
                pageLength: 100,
                columns: [{
                        data: "nomor",
                        className: "center",
                        createdCell: function(td, cellData, rowData, row, col) {
                            $(td).css("vertical-align", "center")
                        }
                    },
                    {
                        data: "subjectsCodeOld",
                        className: "left"
                    },
                    {
                        data: "subjectsNameOld",
                        className: "left"
                    },
                    {
                        data: "sks",
                        className: "center"
                    },
                    {
                        data: "originAlfabetValue",
                        className: "center"
                    },
                    {
                        data: "alfabetValue",
                        className: "center"
                    },
                    {
                        data: null,
                        className: "center",
                        render: function(data) {
                           if (dataStudent.transcriptConvertionStatusId == 5 || dataStudent.transcriptConvertionStatusId == 10) {
                                return ``;
                           } else {
                                return `<div class="dropdown">
                                <button class="btn red btn-outline btn-circle dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" style="margin-right: 0px">
                                    Aksi
                                    <span class="caret"><i class="fa fa-angle-down"></i></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                    <a class="dropdown-item" href="#" onclick="editNilaiMkTranskrip(this)" value="${data.subjectsCodeOld}|${data.subjectsNameOld}|${data.sks}|${data.gradeValuesId}|${data.gradeConvertionAwalId}|${data.originAlfabetValue}|${data.originAlfabetValueId}"><i class="fa fa-edit"></i> Edit</a>
                                    <a class="dropdown-item" href="#" onclick="deleteNilaiMkTranskrip(this)" value="${data.gradeConvertionAwalId}"><i class="fa fa-trash"></i> Hapus</a>
                                </ul>
                            </div>`
                           }
                        }
                    }
                ]
            })
        }
    </script>
</body>

</html>